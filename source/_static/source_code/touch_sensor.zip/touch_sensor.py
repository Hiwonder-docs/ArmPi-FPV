#!/usr/bin/env python3
# coding=utf8
# 第15章 拓展课程之传感器开发与应用\1.拓展课程-传感器基础开发课\第4课 触摸传感器检测
import time
import gpiod
from common.ros_robot_controller_sdk import Board

board = Board()

## 初始化引脚模式
chip = gpiod.chip("gpiochip4")
touch = chip.get_line(7) #BCM
config = gpiod.line_request()
config.consumer = 'touch'
config.request_type = gpiod.line_request.DIRECTION_INPUT
touch.request(config)

pressed = False
while True:
    if touch.get_value() == 0: # 读取引脚数字值
        time.sleep(0.05)
        if touch.get_value() == 0:
            if not pressed:  # 这里做一个判断，防止反复响
                pressed = True
                board.set_buzzer(1900, 0.1, 0.9, 1)  # 设置蜂鸣器响0.1秒
    else:
        pressed = False
