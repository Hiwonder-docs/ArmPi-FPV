#!/usr/bin/env python3
# coding=utf8
# 第15章 拓展课程之传感器开发与应用\1.拓展课程-传感器基础开发课\第8课 数码管显示
import time
from sensor import dot_matrix_sensor
from sensor import ultrasonic_sensor

dms = dot_matrix_sensor.TM1640(dio=7, clk=8)

s = ultrasonic_sensor.Ultrasonic()
# 设置超声波RGB颜色渐变模式
s.setBreathCycle(0, 0, 2000)
s.setBreathCycle(1, 0, 2000)

while True:
    distance = s.getDistance()/10 #获取超声波测距数据,单位cm
    print('dist:',distance)
    distance_int = int(distance)
    dms.set_number(distance_int)
    dms.update_display()
    time.sleep(0.1)
