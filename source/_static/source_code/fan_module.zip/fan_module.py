#!/usr/bin/env python3
# coding=utf8
# 第15章 拓展课程之传感器开发与应用\1.拓展课程-传感器基础开发课\第9课 风扇模块控制
import time
import gpiod

## 初始化引脚模式
chip = gpiod.chip("gpiochip4")
fanPin1 = chip.get_line(8)
fanPin2 = chip.get_line(7)
config = gpiod.line_request()
config.consumer = "pin1"
config.request_type = gpiod.line_request.DIRECTION_OUTPUT
fanPin1.request(config)

config = gpiod.line_request()
config.consumer = "pin2"
config.request_type = gpiod.line_request.DIRECTION_OUTPUT
fanPin2.request(config)

## 开启风扇, 顺时针
fanPin1.set_value(1)  # 设置引脚输出高电平
fanPin2.set_value(0)  # 设置引脚输出低电平

## 延时3秒
time.sleep(3)

#逆时针
fanPin1.set_value(0)  
fanPin2.set_value(1)  

time.sleep(3)

## 关闭风扇
fanPin1.set_value(0)  # 设置引脚输出高电平
fanPin2.set_value(0)  # 设置引脚输出低电平
